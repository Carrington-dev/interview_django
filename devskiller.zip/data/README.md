Local database files goes here. You can delete this folder if you are no longer user SQLite.
